# README #

This is basic starter template for creating Jekyll projects.

### Run site ###

1. Navigate to site folder in terminal
2. Write this command in terminal:
```
#!bash

jekyll serve
```

You´re done! The site should be running on http://localhost:4000


### How do I jekyll? ###

* [Official Jekyll Site](http://jekyllrb.com/)
* [Tips and Tricks](http://jekyll.tips/)
* [Jekyll Forum](https://talk.jekyllrb.com/)

### Liquid Templating language ###

* [Liquid for Designers](https://github.com/Shopify/liquid/wiki/Liquid-for-Designers)